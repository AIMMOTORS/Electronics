#ifndef BATTERYSTRUCTS_H
#define BATTERYSTRUCTS_H

//Other params
#define MAXDEBUGLVL 2

/**
 * @brief Struct created for JK BMS ID 0x79
 * It will fetch individual cell voltages
 */
struct BatteryData79 {
  uint16_t cellVoltages[20];
  bool readSuccess79 = 0;
};

/**
 * @brief Struct created for JK BMS ID 0x82
 * It will fetch Battery Temperature
 */
struct BatteryData82 {
  uint16_t Temperature = 0;
  float batt_temp = 0;
  bool readSuccess82 = 0;
};

/**
 * @brief Struct created for JK BMS ID 0x83
 * It will fetch Voltage
 */
struct BatteryData83 {
  float Voltage = 0;
  bool readSuccess83 = 0;
};

/**
 * @brief Struct created for JK BMS ID 0xAD
 * It will provide constant calibrated current value (from JK BMS App settings)
 */
struct BatteryDataAD {
  float Current = 0;
  bool readSuccessAD = 0;
};

/**
 * @brief Struct created for JK BMS ID 0x84
 * It will fetch Current
 */
struct BatteryData84 {
  float Current = 0;
  bool readSuccess84 = 0;
};

/**
 * @brief Struct created for JK BMS ID 0x85
 * It will fetch  Battery residual capacity
 */
struct BatteryData85 {
  uint8_t SoC = 0;
  bool readSuccess85 = 0;
};

/**
 * @brief Struct created for JK BMS ID 0x87
 * It will fetch Cycle times of battery use/cycle count
 */
struct BatteryData87 {
  uint16_t Cycle_count = 0;
  bool readSuccess87 = 0;
};

/**
 * @brief Struct created for JK BMS ID 0xB9
 * It will fetch Actual Battery Capacity
 */
struct BatteryDataB9 {
  float Actual_battery_capacity = 0;
  bool readSuccessB9 = 0;
};

/**
 * @brief Struct created for JK BMS ID 0xAA
 * It will fetch Actual Battery Capacity
 */
struct BatteryDataAA {
  float Total_battery_capacity = 0;
  bool readSuccessAA = 0;
};

/**
 * @brief Struct created for JK BMS ID 0xAB
 * It will fetch Charge MOS Tube State
 */
struct BatteryDataAB {
  uint8_t Charge_MOS_State = 0;
  bool readSuccessAB = 0;
};

/**
 * @brief Struct created for JK BMS ID 0xAC
 * It will fetch Discharge MOS Tube State
 */
struct BatteryDataAC {
  uint8_t Discharge_MOS_State = 0;
  bool readSuccessAC = 0;
};

typedef struct BatteryData79 bmsData79;
typedef struct BatteryData82 bmsData82;
typedef struct BatteryData83 bmsData83;
typedef struct BatteryData84 bmsData84;
typedef struct BatteryDataAD bmsDataAD;
typedef struct BatteryData85 bmsData85;
typedef struct BatteryData87 bmsData87;
typedef struct BatteryDataB9 bmsDataB9;
typedef struct BatteryDataAA bmsDataAA;
typedef struct BatteryDataAB bmsDataAB;
typedef struct BatteryDataAC bmsDataAC;

#endif // BATTERYSTRUCTS_H
