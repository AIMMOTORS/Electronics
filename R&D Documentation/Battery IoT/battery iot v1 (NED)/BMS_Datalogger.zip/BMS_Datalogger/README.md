Overview

The goal of this project is to collect data from Daly BMS via UART communication and store it in a file system. It also provides a web server interface for downloading and managing log files and a debugging mode for configuration and monitoring.

The code communicates with the DALY BMS via UART. It works in a way that first the respective data IDs are sent to DALY to request data. If the data IDs match, DALY responds with the respective data which is than decoded. 
The data is then stored in a file and also displayed on a web server. The file can be downloaded and deleted from the server which provides this interface. 
 
IDs:
90: voltage, current, SoC
91: max cell voltage, min cell voltage, no. of cell with max voltage and no. of cell with min voltage
92: maximum temperature, minimum temperature, cell no. with max temp and cell no. with min temp
93: Charge MOS State, Discharge MOS State, BMS Life and Remaining Capacity
94: Battery string, Charger status, load status and DIO state
95: Individual cell voltages
96: Cell temperature

Function of the individual files:
-) BMSDataloggerFile.ino (main program):

This file contains the main program logic for the BMS data logger.
It includes libraries for WiFi, web server, and LittleFS (a file system for microcontrollers).
It defines functions for setting up WiFi, data logging, handling web requests (for downloading and deleting logs), and debugging mode.
In debugging mode, users can change debug level, remove log file, and enable/disable the web server.


-) batterystructs.h:

This file defines structures for storing various data points received from the BMS, such as voltage, current, SoC (State of Charge), cell voltages, temperatures, etc.
Each data point has a corresponding struct member variable with an appropriate data type.


-) debugging.ino:

This file implements debugging functionalities.
It allows users to enter a settings mode by pressing 's' key on the serial monitor.
In settings mode, users can:
Increase/decrease debug level
Exit settings mode
Remove log file
Read log file contents
Enable/disable the web server


-) uartBMSread.ino:

This file handles communication with the BMS through UART (serial communication).
It defines functions for:
Setting up UART communication
Creating CAN (Controller Area Network) message IDs to request specific data from the BMS
Receiving data from the BMS via UART
Extracting and decoding data from different BMS data IDs (0x90 to 0x98)
Printing debug messages